# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Rails32::Application.config.secret_token = '5222894134c2574b426b8391396bb86a39d03eaef626ad4a18eb038e2d251fd65e9964e3ae247af4e4fae82fa89b4622493df6e7e85b9bd75ab51d37513c82ae'
