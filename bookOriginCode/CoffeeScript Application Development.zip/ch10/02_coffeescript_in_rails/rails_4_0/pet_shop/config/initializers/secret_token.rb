# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
Rails40::Application.config.secret_key_base = '61cfc63b65095bb5fe4404987bb22bb5fd77e083530ddfb7772b2431b6897255018d49da0c4fdbc1e2ab2b435a976f24926b8a1f3c9ea32cd09388c853f18b15'
