Brunch with Brunch
==================

This is as minimal of a project as possible with brunch. It includes only
javascript, css, and optimization plugins. The rest is left up to you.

